\# Wallet Transfer - Distributed Saga with CQRS



\## Architecture Overview



This solution implements a distributed transaction for wallet transfers using the Saga pattern with orchestration, CQRS, and event-driven architecture.



\### Key Features



\- \*\*Atomic transfers\*\* across different wallets without distributed transactions

\- \*\*Automatic compensation\*\* on failure (reverse debit if credit fails)

\- \*\*CQRS with projections\*\* for read model consistency (<500ms response time)

\- \*\*Concurrency safety\*\* with distributed locks

\- \*\*Idempotency\*\* at saga level

\- \*\*FX timeout handling\*\* with ambiguous state management



\### Technologies



\- .NET 8

\- PostgreSQL (Write \& Read models)

\- Redis (Cache \& Distributed Lock)

\- Kafka (Event Bus)

\- Serilog (Logging)



\### Running the Application



1\. Start infrastructure:

```bash

docker-compose up -d

