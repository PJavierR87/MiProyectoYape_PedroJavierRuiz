﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System.Diagnostics;
using System.Text.Json;
using WalletTransfer.ReadModel.DbContext;
using WalletTransfer.ReadModel.Models;

namespace WalletTransfer.ReadModel.Queries;

public class TransferQueries
{
    private readonly ReadDbContext _dbContext;
    private readonly IDistributedCache _cache;
    private readonly ILogger<TransferQueries> _logger;

    public TransferQueries(ReadDbContext dbContext, IDistributedCache cache, ILogger<TransferQueries> logger)
    {
        _dbContext = dbContext;
        _cache = cache;
        _logger = logger;
    }

    public async Task<TransferView?> GetTransfer(string transferId)
    {
        var stopwatch = Stopwatch.StartNew();

        try
        {
            // Cache-first approach for sub-500ms response
            var cached = await _cache.GetStringAsync($"transfer:{transferId}");
            if (cached != null)
            {
                stopwatch.Stop();
                _logger.LogDebug("Cache hit for transfer {TransferId} in {Elapsed}ms", transferId, stopwatch.ElapsedMilliseconds);
                return JsonSerializer.Deserialize<TransferView>(cached);
            }

            // Cache miss - query database
            var transfer = await _dbContext.TransferViews
                .AsNoTracking()
                .FirstOrDefaultAsync(t => t.TransferId == transferId);

            stopwatch.Stop();

            if (stopwatch.ElapsedMilliseconds > 500)
            {
                _logger.LogWarning("Transfer query for {TransferId} took {Elapsed}ms", transferId, stopwatch.ElapsedMilliseconds);
            }

            if (transfer != null)
            {
                // Store in cache for future requests
                await _cache.SetStringAsync(
                    $"transfer:{transferId}",
                    JsonSerializer.Serialize(transfer),
                    new DistributedCacheEntryOptions
                    {
                        SlidingExpiration = TimeSpan.FromMinutes(5),
                        AbsoluteExpirationRelativeToNow = TimeSpan.FromHours(1)
                    });
            }

            return transfer;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error retrieving transfer {TransferId}", transferId);
            throw;
        }
    }

    public async Task<List<TransferView>> GetTransfersByWallet(string walletId, int page = 1, int pageSize = 20)
    {
        var query = _dbContext.TransferViews
            .AsNoTracking()
            .Where(t => t.FromWalletId == walletId || t.ToWalletId == walletId)
            .OrderByDescending(t => t.CreatedAt);

        return await query
            .Skip((page - 1) * pageSize)
            .Take(pageSize)
            .ToListAsync();
    }
}