﻿using Microsoft.EntityFrameworkCore;
using WalletTransfer.ReadModel.Models;

namespace WalletTransfer.ReadModel.DbContext;

public class ReadDbContext : Microsoft.EntityFrameworkCore.DbContext
{
    public DbSet<TransferView> TransferViews { get; set; }

    public ReadDbContext(DbContextOptions<ReadDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<TransferView>(entity =>
        {
            entity.ToTable("transfer_views");
            entity.HasKey(e => e.TransferId);

            entity.Property(e => e.TransferId)
                .HasColumnName("transfer_id")
                .HasMaxLength(50);

            entity.Property(e => e.FromWalletId)
                .HasColumnName("from_wallet_id")
                .HasMaxLength(50);

            entity.Property(e => e.ToWalletId)
                .HasColumnName("to_wallet_id")
                .HasMaxLength(50);

            entity.Property(e => e.Amount)
                .HasColumnName("amount")
                .HasPrecision(19, 4);

            entity.Property(e => e.Currency)
                .HasColumnName("currency")
                .HasMaxLength(3);

            entity.Property(e => e.ExchangeRate)
                .HasColumnName("exchange_rate")
                .HasPrecision(19, 6);

            entity.Property(e => e.Status)
                .HasColumnName("status")
                .HasMaxLength(50);

            entity.Property(e => e.CreatedAt)
                .HasColumnName("created_at");

            entity.Property(e => e.DebitCompletedAt)
                .HasColumnName("debit_completed_at");

            entity.Property(e => e.CreditCompletedAt)
                .HasColumnName("credit_completed_at");

            entity.Property(e => e.CompletedAt)
                .HasColumnName("completed_at");

            entity.Property(e => e.Version)
                .HasColumnName("version");

            entity.HasIndex(e => e.Status);
            entity.HasIndex(e => e.CreatedAt);
            entity.HasIndex(e => e.FromWalletId);
            entity.HasIndex(e => e.ToWalletId);
        });
    }
}