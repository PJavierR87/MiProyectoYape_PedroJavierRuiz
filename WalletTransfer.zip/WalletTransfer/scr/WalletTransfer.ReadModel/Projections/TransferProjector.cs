﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Distributed;
using Microsoft.Extensions.Logging;
using System.Text.Json;
using WalletTransfer.Domain.Events;
using WalletTransfer.ReadModel.DbContext;
using WalletTransfer.ReadModel.Models;

namespace WalletTransfer.ReadModel.Projections;

public class TransferProjector
{
    private readonly ReadDbContext _dbContext;
    private readonly IDistributedCache _cache;
    private readonly ILogger<TransferProjector> _logger;

    public TransferProjector(
        ReadDbContext dbContext,
        IDistributedCache cache,
        ILogger<TransferProjector> logger)
    {
        _dbContext = dbContext;
        _cache = cache;
        _logger = logger;
    }

    public async Task Handle(TransferStartedEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.TransferId = @event.TransferId.Value;
            view.FromWalletId = @event.FromWallet.Value;
            view.ToWalletId = @event.ToWallet.Value;
            view.Amount = @event.Amount.Amount;
            view.Currency = @event.Amount.Currency;
            view.Status = "Pending";
            view.CreatedAt = @event.Timestamp;
            view.Version = 0;
        });
    }

    public async Task Handle(WalletDebitedEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.DebitCompletedAt = @event.Timestamp;
            view.Status = "DebitCompleted";
            view.Version++;
        });
    }

    public async Task Handle(WalletCreditedEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.CreditCompletedAt = @event.Timestamp;
            view.Status = "CreditCompleted";
            view.Version++;
        });
    }

    public async Task Handle(FXSettledEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.ExchangeRate = @event.ExchangeRate.Amount;
            view.Status = "Settled";
            view.Version++;
        });
    }

    public async Task Handle(TransferCompletedEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.CompletedAt = @event.Timestamp;
            view.Status = "Completed";
            view.Version++;
        });

        // Invalidate cache after completion
        await _cache.RemoveAsync($"transfer:{@event.TransferId.Value}");
    }

    public async Task Handle(TransferFailedEvent @event)
    {
        await UpdateTransfer(@event.TransferId.Value, view =>
        {
            view.Status = "Failed";
            view.Version++;
        });

        await _cache.RemoveAsync($"transfer:{@event.TransferId.Value}");
    }

    private async Task UpdateTransfer(string transferId, Action<TransferView> update)
    {
        var maxRetries = 3;
        var retryCount = 0;

        while (retryCount < maxRetries)
        {
            try
            {
                var view = await _dbContext.TransferViews
                    .FirstOrDefaultAsync(t => t.TransferId == transferId);

                if (view == null)
                {
                    view = new TransferView { TransferId = transferId, Version = 0 };
                    _dbContext.TransferViews.Add(view);
                }

                var originalVersion = view.Version;
                update(view);

                await _dbContext.SaveChangesAsync();

                // Update cache
                await _cache.SetStringAsync(
                    $"transfer:{transferId}",
                    JsonSerializer.Serialize(view),
                    new DistributedCacheEntryOptions
                    {
                        SlidingExpiration = TimeSpan.FromMinutes(5)
                    });

                _logger.LogDebug("Transfer {TransferId} updated to version {Version}", transferId, view.Version);
                return;
            }
            catch (DbUpdateConcurrencyException ex)
            {
                retryCount++;
                _logger.LogWarning(ex, "Concurrency conflict updating transfer {TransferId}, retry {Retry}",
                    transferId, retryCount);

                if (retryCount >= maxRetries)
                {
                    _logger.LogError("Failed to update transfer {TransferId} after {Retries} retries",
                        transferId, maxRetries);
                    throw;
                }

                await Task.Delay(100 * retryCount);
            }
        }
    }
}