﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WalletTransfer.ReadModel.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate_ReadModel : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "transfer_views",
                columns: table => new
                {
                    transfer_id = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    from_wallet_id = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    to_wallet_id = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    amount = table.Column<decimal>(type: "numeric(19,4)", precision: 19, scale: 4, nullable: false),
                    currency = table.Column<string>(type: "character varying(3)", maxLength: 3, nullable: false),
                    exchange_rate = table.Column<decimal>(type: "numeric(19,6)", precision: 19, scale: 6, nullable: false),
                    status = table.Column<string>(type: "character varying(50)", maxLength: 50, nullable: false),
                    created_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    debit_completed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    credit_completed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    completed_at = table.Column<DateTime>(type: "timestamp with time zone", nullable: true),
                    version = table.Column<int>(type: "integer", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_transfer_views", x => x.transfer_id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_transfer_views_created_at",
                table: "transfer_views",
                column: "created_at");

            migrationBuilder.CreateIndex(
                name: "IX_transfer_views_from_wallet_id",
                table: "transfer_views",
                column: "from_wallet_id");

            migrationBuilder.CreateIndex(
                name: "IX_transfer_views_status",
                table: "transfer_views",
                column: "status");

            migrationBuilder.CreateIndex(
                name: "IX_transfer_views_to_wallet_id",
                table: "transfer_views",
                column: "to_wallet_id");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "transfer_views");
        }
    }
}
