﻿namespace WalletTransfer.ReadModel.Models;

public class TransferView
{
    public string TransferId { get; set; } = string.Empty;
    public string FromWalletId { get; set; } = string.Empty;
    public string ToWalletId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
    public decimal ExchangeRate { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
    public DateTime? DebitCompletedAt { get; set; }
    public DateTime? CreditCompletedAt { get; set; }
    public DateTime? CompletedAt { get; set; }
    public int Version { get; set; }
}