﻿using Microsoft.Extensions.Logging;
using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Results;
using WalletTransfer.Application.Services;
using WalletTransfer.Domain.Entities; // Importante: usar Entities
using WalletTransfer.Domain.Enums;
using WalletTransfer.Domain.Events;
using WalletTransfer.Domain.Exceptions;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Orchestrator.Saga;

public class TransferOrchestrator
{
    private readonly IWalletService _walletService;
    private readonly IFXService _fxService;
    private readonly ITransferRepository _repository;
    private readonly IEventPublisher _eventPublisher;
    private readonly IDistributedLock _lock;
    private readonly ILogger<TransferOrchestrator> _logger;

    public TransferOrchestrator(
        IWalletService walletService,
        IFXService fxService,
        ITransferRepository repository,
        IEventPublisher eventPublisher,
        IDistributedLock @lock,
        ILogger<TransferOrchestrator> logger)
    {
        _walletService = walletService;
        _fxService = fxService;
        _repository = repository;
        _eventPublisher = eventPublisher;
        _lock = @lock;
        _logger = logger;
    }

    public async Task<TransferResult> StartTransfer(StartTransferCommand command)
    {
        // Idempotency check at saga level
        var existingSaga = await _repository.GetByIdempotencyKey(command.IdempotencyKey);
        if (existingSaga != null)
        {
            _logger.LogInformation("Transfer already processed with idempotency key {Key}", command.IdempotencyKey);
            return new TransferResult(existingSaga.Id, existingSaga.Status);
        }

        // Distributed lock to prevent concurrent debits
        await using var lockHandle = await _lock.AcquireLock(
            $"wallet:{command.FromWallet.Value}",
            TimeSpan.FromSeconds(10));

        if (!lockHandle.Acquired)
        {
            throw new ConcurrencyException($"Wallet {command.FromWallet} is currently locked for another transfer");
        }

        var sagaState = new TransferSagaState(
            command.TransferId,
            command.IdempotencyKey,
            command.FromWallet,
            command.ToWallet,
            command.Amount,
            command.ExchangeRate);

        await _repository.Add(sagaState);
        await _eventPublisher.Publish(new TransferStartedEvent(
            command.TransferId,
            command.FromWallet,
            command.ToWallet,
            command.Amount));

        // Start saga execution asynchronously
        _ = Task.Run(() => ExecuteSaga(sagaState.Id));

        return new TransferResult(command.TransferId, TransferStatus.Pending);
    }

    private async Task ExecuteSaga(TransferId transferId)
    {
        var saga = await _repository.GetById(transferId);
        if (saga == null)
        {
            _logger.LogError("Saga not found for transfer {TransferId}", transferId);
            return;
        }

        try
        {
            _logger.LogInformation("Executing saga step {Step} for transfer {TransferId}", saga.CurrentStep, transferId);

            switch (saga.CurrentStep)
            {
                case 0:
                    await StepDebitWallet(saga);
                    await ExecuteSaga(transferId);
                    break;
                case 1:
                    await StepCreditWallet(saga);
                    await ExecuteSaga(transferId);
                    break;
                case 2:
                    await StepSettleFX(saga);
                    await ExecuteSaga(transferId);
                    break;
                case 3:
                    await StepEmitReceipt(saga);
                    break;
                default:
                    _logger.LogInformation("Saga completed for transfer {TransferId}", transferId);
                    break;
            }
        }
        catch (Exception ex) when (ex is not ConcurrencyException)
        {
            await HandleFailure(saga, ex);
        }
    }

    private async Task StepDebitWallet(TransferSagaState saga)
    {
        _logger.LogInformation("Step 1: Debiting wallet {WalletId} for transfer {TransferId}",
            saga.FromWalletId, saga.Id);

        var command = new DebitCommand(
            saga.Id,
            saga.FromWalletId,
            saga.Amount,
            $"{saga.IdempotencyKey}:debit");

        var result = await _walletService.Debit(command);

        if (!result.Success)
            throw new BusinessException($"Debit failed: {result.Error}");

        saga.UpdateStep(1, TransferStatus.DebitCompleted);
        await _repository.Update(saga);
        await _eventPublisher.Publish(new WalletDebitedEvent(saga.Id, saga.FromWalletId, saga.Amount));

        _logger.LogInformation("Debit completed for transfer {TransferId}", saga.Id);
    }

    private async Task StepCreditWallet(TransferSagaState saga)
    {
        _logger.LogInformation("Step 2: Crediting wallet {WalletId} for transfer {TransferId}",
            saga.ToWalletId, saga.Id);

        var convertedAmount = saga.Amount.Convert(saga.ExchangeRate.Currency, saga.ExchangeRate.Amount);

        var command = new CreditCommand(
            saga.Id,
            saga.ToWalletId,
            convertedAmount,
            $"{saga.IdempotencyKey}:credit");

        var result = await _walletService.Credit(command);

        if (!result.Success)
        {
            await CompensateDebit(saga);
            throw new BusinessException($"Credit failed: {result.Error}");
        }

        saga.UpdateStep(2, TransferStatus.CreditCompleted);
        await _repository.Update(saga);
        await _eventPublisher.Publish(new WalletCreditedEvent(saga.Id, saga.ToWalletId, convertedAmount));

        _logger.LogInformation("Credit completed for transfer {TransferId}", saga.Id);
    }

    private async Task StepSettleFX(TransferSagaState saga)
    {
        _logger.LogInformation("Step 3: Settling FX for transfer {TransferId}", saga.Id);

        var command = new FxSettlementCommand(
            saga.Id,
            saga.Amount.Currency,
            saga.ExchangeRate.Currency,
            saga.Amount.Amount,
            saga.ExchangeRate.Amount);

        using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5));

        try
        {
            var result = await _fxService.Settle(command, cts.Token);

            if (!result.Success)
            {
                await CompensateDebit(saga);
                await CompensateCredit(saga);
                throw new BusinessException($"FX settlement failed: {result.Error}");
            }

            saga.UpdateStep(3, TransferStatus.Settled);
            await _repository.Update(saga);
            await _eventPublisher.Publish(new FXSettledEvent(saga.Id, saga.ExchangeRate));

            _logger.LogInformation("FX settlement completed for transfer {TransferId}", saga.Id);
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("FX settlement timeout for transfer {TransferId}. State ambiguous.", saga.Id);

            var actualStatus = await CheckFxStatusWithRetry(saga.Id);

            if (actualStatus == FxStatus.Confirmed)
            {
                saga.UpdateStep(3, TransferStatus.Settled);
                await _repository.Update(saga);
                await _eventPublisher.Publish(new FXSettledEvent(saga.Id, saga.ExchangeRate));
                await StepEmitReceipt(saga);
            }
            else if (actualStatus == FxStatus.Failed)
            {
                await CompensateDebit(saga);
                await CompensateCredit(saga);
                throw new BusinessException("FX settlement failed after timeout check");
            }
            else
            {
                saga.MarkAmbiguous("FX settlement timeout - status unknown after retries");
                await _repository.Update(saga);
                await _eventPublisher.Publish(new TransferFailedEvent(saga.Id,
                    "FX settlement timeout - requires manual review", "SettleFX"));
                throw new TimeoutException("FX settlement status ambiguous");
            }
        }
    }

    private async Task StepEmitReceipt(TransferSagaState saga)
    {
        _logger.LogInformation("Step 4: Emitting receipt for transfer {TransferId}", saga.Id);

        var receiptUrl = $"https://receipts.wallettransfer.com/{saga.Id.Value}";

        saga.MarkCompleted();
        await _repository.Update(saga);
        await _eventPublisher.Publish(new TransferCompletedEvent(saga.Id, receiptUrl));

        _logger.LogInformation("Transfer {TransferId} completed successfully", saga.Id);
    }

    private async Task CompensateDebit(TransferSagaState saga)
    {
        _logger.LogWarning("Compensating debit for transfer {TransferId}", saga.Id);

        saga.MarkCompensating();
        await _repository.Update(saga);

        var command = new ReverseDebitCommand(
            saga.Id,
            saga.FromWalletId,
            saga.Amount,
            $"{saga.IdempotencyKey}:reverse-debit",
            "Credit failed");

        var result = await _walletService.ReverseDebit(command);

        if (!result.Success)
        {
            _logger.LogError("CRITICAL: Failed to compensate debit for transfer {TransferId}. Error: {Error}",
                saga.Id, result.Error);
            await _repository.MarkFailedCompensation(saga.Id, result.Error);
            throw new CompensationException($"Failed to compensate debit: {result.Error}");
        }

        await _eventPublisher.Publish(new DebitCompensatedEvent(saga.Id, saga.FromWalletId, saga.Amount, "Credit failed"));
        saga.MarkCompensated();
        await _repository.Update(saga);

        _logger.LogInformation("Debit compensated for transfer {TransferId}", saga.Id);
    }

    private async Task CompensateCredit(TransferSagaState saga)
    {
        _logger.LogWarning("Compensating credit for transfer {TransferId}", saga.Id);

        var convertedAmount = saga.Amount.Convert(saga.ExchangeRate.Currency, saga.ExchangeRate.Amount);

        var command = new ReverseDebitCommand(
            saga.Id,
            saga.ToWalletId,
            convertedAmount,
            $"{saga.IdempotencyKey}:reverse-credit",
            "FX settlement failed");

        var result = await _walletService.ReverseDebit(command);

        if (!result.Success)
        {
            _logger.LogError("CRITICAL: Failed to compensate credit for transfer {TransferId}. Error: {Error}",
                saga.Id, result.Error);
            await _repository.MarkFailedCompensation(saga.Id, result.Error);
            throw new CompensationException($"Failed to compensate credit: {result.Error}");
        }

        _logger.LogInformation("Credit compensated for transfer {TransferId}", saga.Id);
    }

    private async Task HandleFailure(TransferSagaState saga, Exception ex)
    {
        _logger.LogError(ex, "Transfer {TransferId} failed at step {Step}", saga.Id, saga.CurrentStep);

        saga.MarkFailed(ex.Message);
        await _repository.Update(saga);
        await _eventPublisher.Publish(new TransferFailedEvent(saga.Id, ex.Message,
            saga.CurrentStep switch
            {
                0 => "DebitWallet",
                1 => "CreditWallet",
                2 => "SettleFX",
                3 => "EmitReceipt",
                _ => "Unknown"
            }));
    }

    private async Task<FxStatus> CheckFxStatusWithRetry(TransferId transferId)
    {
        for (int i = 0; i < 3; i++)
        {
            try
            {
                var status = await _fxService.GetStatus(transferId);
                if (status != FxStatus.Pending && status != FxStatus.Unknown)
                    return status;

                await Task.Delay(1000 * (i + 1));
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Failed to check FX status for transfer {TransferId}, retry {Retry}",
                    transferId, i + 1);
            }
        }
        return FxStatus.Unknown;
    }
}