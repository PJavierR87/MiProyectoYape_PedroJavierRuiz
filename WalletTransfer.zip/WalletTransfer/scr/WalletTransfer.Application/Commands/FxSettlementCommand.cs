﻿using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Application.Results;

namespace WalletTransfer.Application.Commands;

public class FxSettlementCommand
{
    public TransferId TransferId { get; }
    public string FromCurrency { get; }
    public string ToCurrency { get; }
    public decimal Amount { get; }
    public decimal ExchangeRate { get; }

    public FxSettlementCommand(TransferId transferId, string fromCurrency, string toCurrency, decimal amount, decimal exchangeRate)
    {
        TransferId = transferId;
        FromCurrency = fromCurrency;
        ToCurrency = toCurrency;
        Amount = amount;
        ExchangeRate = exchangeRate;
    }
}