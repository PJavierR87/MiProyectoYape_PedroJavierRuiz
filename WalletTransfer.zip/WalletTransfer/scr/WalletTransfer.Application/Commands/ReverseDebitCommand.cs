﻿using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Application.Results;

namespace WalletTransfer.Application.Commands;

public class ReverseDebitCommand
{
    public TransferId TransferId { get; }
    public WalletId WalletId { get; }
    public Money Amount { get; }
    public string IdempotencyKey { get; }
    public string Reason { get; }

    public ReverseDebitCommand(TransferId transferId, WalletId walletId, Money amount, string idempotencyKey, string reason)
    {
        TransferId = transferId;
        WalletId = walletId;
        Amount = amount;
        IdempotencyKey = idempotencyKey;
        Reason = reason;
    }
}