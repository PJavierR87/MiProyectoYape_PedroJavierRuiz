﻿using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Application.Results;

namespace WalletTransfer.Application.Commands;

public class DebitCommand
{
    public TransferId TransferId { get; }
    public WalletId WalletId { get; }
    public Money Amount { get; }
    public string IdempotencyKey { get; }

    public DebitCommand(TransferId transferId, WalletId walletId, Money amount, string idempotencyKey)
    {
        TransferId = transferId;
        WalletId = walletId;
        Amount = amount;
        IdempotencyKey = idempotencyKey;
    }
}