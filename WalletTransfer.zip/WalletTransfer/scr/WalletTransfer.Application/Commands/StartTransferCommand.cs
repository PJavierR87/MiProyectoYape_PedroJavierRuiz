﻿using MediatR;
using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Application.Results;

namespace WalletTransfer.Application.Commands;

public class StartTransferCommand : IRequest<TransferResult>
{
    public TransferId TransferId { get; }
    public WalletId FromWallet { get; }
    public WalletId ToWallet { get; }
    public Money Amount { get; }
    public Money ExchangeRate { get; }
    public string IdempotencyKey { get; }

    public StartTransferCommand(
        TransferId transferId,
        WalletId fromWallet,
        WalletId toWallet,
        Money amount,
        Money exchangeRate,
        string idempotencyKey)
    {
        TransferId = transferId;
        FromWallet = fromWallet;
        ToWallet = toWallet;
        Amount = amount;
        ExchangeRate = exchangeRate;
        IdempotencyKey = idempotencyKey;
    }
}