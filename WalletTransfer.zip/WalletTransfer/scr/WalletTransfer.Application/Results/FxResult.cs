﻿using WalletTransfer.Domain.Enums;

namespace WalletTransfer.Application.Results;

public class FxResult
{
    public bool Success { get; }
    public string? SettlementId { get; }
    public FxStatus Status { get; }
    public string? Error { get; }

    public FxResult(bool success, string? settlementId = null, FxStatus status = FxStatus.Pending, string? error = null)
    {
        Success = success;
        SettlementId = settlementId;
        Status = status;
        Error = error;
    }
}