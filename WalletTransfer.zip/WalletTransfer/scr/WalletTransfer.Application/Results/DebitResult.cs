﻿namespace WalletTransfer.Application.Results;

public class DebitResult
{
    public bool Success { get; }
    public string? Error { get; }
    public string? TransactionId { get; }

    public DebitResult(bool success, string? error = null, string? transactionId = null)
    {
        Success = success;
        Error = error;
        TransactionId = transactionId;
    }
}