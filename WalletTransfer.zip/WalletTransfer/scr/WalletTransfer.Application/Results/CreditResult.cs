﻿namespace WalletTransfer.Application.Results;

public class CreditResult
{
    public bool Success { get; }
    public string? Error { get; }
    public string? TransactionId { get; }

    public CreditResult(bool success, string? error = null, string? transactionId = null)
    {
        Success = success;
        Error = error;
        TransactionId = transactionId;
    }
}