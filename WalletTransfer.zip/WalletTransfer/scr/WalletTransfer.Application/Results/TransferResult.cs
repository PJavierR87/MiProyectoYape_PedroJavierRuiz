﻿using WalletTransfer.Domain.Enums;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Application.Results;

public class TransferResult
{
    public bool Success { get; }
    public TransferId? TransferId { get; }
    public TransferStatus Status { get; }
    public string? Error { get; }

    public TransferResult(TransferId transferId, TransferStatus status)
    {
        Success = true;
        TransferId = transferId;
        Status = status;
    }

    public TransferResult(string error)
    {
        Success = false;
        Error = error;
    }
}