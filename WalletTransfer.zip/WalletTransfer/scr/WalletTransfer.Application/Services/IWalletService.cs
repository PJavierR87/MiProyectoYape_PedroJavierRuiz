﻿using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Results;

namespace WalletTransfer.Application.Services;

public interface IWalletService
{
    Task<DebitResult> Debit(DebitCommand command);
    Task<CreditResult> Credit(CreditCommand command);
    Task<DebitResult> ReverseDebit(ReverseDebitCommand command);
    Task<bool> IsOperationProcessed(string idempotencyKey);
}