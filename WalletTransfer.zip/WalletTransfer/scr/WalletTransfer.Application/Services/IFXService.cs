﻿using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Results;
using WalletTransfer.Domain.Enums;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Application.Services;

public interface IFXService
{
    Task<FxResult> Settle(FxSettlementCommand command, CancellationToken cancellationToken);
    Task<FxStatus> GetStatus(TransferId transferId);
}