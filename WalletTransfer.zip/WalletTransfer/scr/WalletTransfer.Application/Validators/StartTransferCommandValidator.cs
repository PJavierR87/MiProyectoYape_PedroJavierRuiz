﻿using FluentValidation;
using WalletTransfer.Application.Commands;

namespace WalletTransfer.Application.Validators;

public class StartTransferCommandValidator : AbstractValidator<StartTransferCommand>
{
    public StartTransferCommandValidator()
    {
        RuleFor(x => x.TransferId)
            .NotNull()
            .WithMessage("Transfer ID is required");

        RuleFor(x => x.FromWallet)
            .NotNull()
            .WithMessage("From wallet is required");

        RuleFor(x => x.ToWallet)
            .NotNull()
            .WithMessage("To wallet is required");

        RuleFor(x => x.Amount)
            .NotNull()
            .WithMessage("Amount is required")
            .Must(x => x.Amount > 0)
            .WithMessage("Amount must be greater than zero");

        RuleFor(x => x.ExchangeRate)
            .NotNull()
            .WithMessage("Exchange rate is required")
            .Must(x => x.Amount > 0)
            .WithMessage("Exchange rate must be greater than zero");

        RuleFor(x => x.IdempotencyKey)
            .NotEmpty()
            .WithMessage("Idempotency key is required")
            .MaximumLength(255)
            .WithMessage("Idempotency key cannot exceed 255 characters");

        RuleFor(x => x)
            .Must(x => x.FromWallet != x.ToWallet)
            .WithMessage("Cannot transfer to the same wallet");
    }
}