﻿using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using Polly;
using System.Net.Http.Json;
using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Results;
using WalletTransfer.Application.Services;
using WalletTransfer.Domain.Enums;
using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Infrastructure.Configuration;

namespace WalletTransfer.Infrastructure.ExternalServices.FX;

public class FXService : IFXService
{
    private readonly HttpClient _httpClient;
    private readonly FXConfig _config;
    private readonly ILogger<FXService> _logger;
    private readonly AsyncPolicy<HttpResponseMessage> _retryPolicy;

    public FXService(HttpClient httpClient, IOptions<FXConfig> config, ILogger<FXService> logger)
    {
        _httpClient = httpClient;
        _config = config.Value;
        _logger = logger;

        _retryPolicy = Policy<HttpResponseMessage>
            .Handle<HttpRequestException>()
            .OrResult(r => !r.IsSuccessStatusCode)
            .WaitAndRetryAsync(
                _config.RetryCount,
                retryAttempt => TimeSpan.FromMilliseconds(Math.Pow(2, retryAttempt) * _config.RetryDelayMs),
                onRetry: (outcome, timespan, retryCount, context) =>
                {
                    _logger.LogWarning("Retry {RetryCount} for FX service after {Timespan}ms",
                        retryCount, timespan.TotalMilliseconds);
                });
    }

    public async Task<FxResult> Settle(FxSettlementCommand command, CancellationToken cancellationToken)
    {
        try
        {
            var request = new
            {
                TransferId = command.TransferId.Value,
                FromCurrency = command.FromCurrency,
                ToCurrency = command.ToCurrency,
                Amount = command.Amount,
                ExchangeRate = command.ExchangeRate
            };

            using var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken);
            cts.CancelAfter(TimeSpan.FromSeconds(_config.TimeoutSeconds));

            var response = await _retryPolicy.ExecuteAsync(async ct =>
                await _httpClient.PostAsJsonAsync("/api/settle", request, ct), cts.Token);

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<FxSettlementResponse>(cancellationToken);
                return new FxResult(true, result?.SettlementId, FxStatus.Confirmed);
            }

            return new FxResult(false, error: $"FX settlement failed with status {response.StatusCode}");
        }
        catch (OperationCanceledException)
        {
            _logger.LogWarning("FX settlement timeout for transfer {TransferId}", command.TransferId);
            return new FxResult(false, status: FxStatus.Pending, error: "Timeout waiting for FX settlement");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FX settlement failed for transfer {TransferId}", command.TransferId);
            return new FxResult(false, error: ex.Message);
        }
    }

    public async Task<FxStatus> GetStatus(TransferId transferId)
    {
        try
        {
            var response = await _httpClient.GetAsync($"/api/status/{transferId.Value}");

            if (response.IsSuccessStatusCode)
            {
                var result = await response.Content.ReadFromJsonAsync<FxStatusResponse>();
                return result?.Status switch
                {
                    "confirmed" => FxStatus.Confirmed,
                    "failed" => FxStatus.Failed,
                    _ => FxStatus.Pending
                };
            }

            return FxStatus.Unknown;
        }
        catch
        {
            return FxStatus.Unknown;
        }
    }
}

internal class FxSettlementResponse
{
    public string SettlementId { get; set; } = string.Empty;
}

internal class FxStatusResponse
{
    public string Status { get; set; } = string.Empty;
}