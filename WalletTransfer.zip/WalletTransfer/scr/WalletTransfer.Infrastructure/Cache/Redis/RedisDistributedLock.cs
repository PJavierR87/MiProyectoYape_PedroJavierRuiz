﻿using Microsoft.Extensions.Logging;
using StackExchange.Redis;
using WalletTransfer.Domain.Interfaces;

namespace WalletTransfer.Infrastructure.Cache.Redis;

public class RedisDistributedLock : IDistributedLock
{
    private readonly IConnectionMultiplexer _redis;
    private readonly ILogger<RedisDistributedLock> _logger;

    public RedisDistributedLock(IConnectionMultiplexer redis, ILogger<RedisDistributedLock> logger)
    {
        _redis = redis;
        _logger = logger;
    }

    public async Task<ILockHandle> AcquireLock(string resource, TimeSpan timeout)
    {
        var db = _redis.GetDatabase();
        var lockKey = $"lock:{resource}";
        var lockValue = Guid.NewGuid().ToString();

        var acquired = await db.StringSetAsync(lockKey, lockValue, timeout, When.NotExists);

        if (acquired)
        {
            _logger.LogDebug("Lock acquired for resource {Resource}", resource);
            return new RedisLockHandle(_redis, lockKey, lockValue, _logger);
        }

        _logger.LogDebug("Failed to acquire lock for resource {Resource}", resource);
        return new RedisLockHandle(false);
    }
}

public class RedisLockHandle : ILockHandle
{
    private readonly IConnectionMultiplexer? _redis;
    private readonly string? _lockKey;
    private readonly string? _lockValue;
    private readonly ILogger? _logger;

    public bool Acquired { get; }

    public RedisLockHandle(bool acquired)
    {
        Acquired = acquired;
    }

    public RedisLockHandle(IConnectionMultiplexer redis, string lockKey, string lockValue, ILogger logger)
    {
        _redis = redis;
        _lockKey = lockKey;
        _lockValue = lockValue;
        _logger = logger;
        Acquired = true;
    }

    public async ValueTask DisposeAsync()
    {
        if (Acquired && _redis != null)
        {
            var db = _redis.GetDatabase();
            var script = @"
                if redis.call('get', KEYS[1]) == ARGV[1] then
                    return redis.call('del', KEYS[1])
                else
                    return 0
                end";

            await db.ScriptEvaluateAsync(script, new RedisKey[] { _lockKey! }, new RedisValue[] { _lockValue! });
            _logger?.LogDebug("Lock released for resource {LockKey}", _lockKey);
        }
    }
}