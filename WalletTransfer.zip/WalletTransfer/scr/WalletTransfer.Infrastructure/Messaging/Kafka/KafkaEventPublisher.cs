﻿using Confluent.Kafka;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System.Text.Json;
using WalletTransfer.Domain.Events;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Infrastructure.Configuration;

namespace WalletTransfer.Infrastructure.Messaging.Kafka;

public class KafkaEventPublisher : IEventPublisher
{
    private readonly IProducer<string, string> _producer;
    private readonly KafkaConfig _config;
    private readonly ILogger<KafkaEventPublisher> _logger;

    public KafkaEventPublisher(IOptions<KafkaConfig> config, ILogger<KafkaEventPublisher> logger)
    {
        _config = config.Value;
        _logger = logger;

        var producerConfig = new ProducerConfig
        {
            BootstrapServers = _config.BootstrapServers,
            EnableIdempotence = true,
            MessageSendMaxRetries = 3
        };

        _producer = new ProducerBuilder<string, string>(producerConfig).Build();
    }

    public async Task Publish<T>(T @event) where T : IEvent
    {
        try
        {
            var message = JsonSerializer.Serialize(@event);
            var result = await _producer.ProduceAsync(
                _config.TopicEvents,
                new Message<string, string>
                {
                    Key = @event.GetType().Name,
                    Value = message
                });

            _logger.LogInformation("Event {EventType} published to partition {Partition} at offset {Offset}",
                @event.EventType, result.Partition, result.Offset);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to publish event {EventType}", @event.EventType);
            throw;
        }
    }
}