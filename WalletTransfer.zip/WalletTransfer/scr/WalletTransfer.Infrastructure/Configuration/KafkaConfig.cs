﻿namespace WalletTransfer.Infrastructure.Configuration;

public class KafkaConfig
{
    public string BootstrapServers { get; set; } = "localhost:9092";
    public string TopicEvents { get; set; } = "wallet-events";
    public string ConsumerGroup { get; set; } = "wallet-orchestrator";
}