﻿using Microsoft.Extensions.Logging;
using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Results;
using WalletTransfer.Application.Services;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Infrastructure.Services;

public class WalletService : IWalletService
{
    private readonly IWalletRepository _repository;
    private readonly IDistributedLock _lock;
    private readonly ILogger<WalletService> _logger;

    public WalletService(
        IWalletRepository repository,
        IDistributedLock @lock,
        ILogger<WalletService> logger)
    {
        _repository = repository;
        _lock = @lock;
        _logger = logger;
    }

    public async Task<DebitResult> Debit(DebitCommand command)
    {
        // Idempotency check
        if (await _repository.IsOperationProcessed(command.IdempotencyKey))
        {
            _logger.LogInformation("Debit operation already processed for key {Key}", command.IdempotencyKey);
            return new DebitResult(true);
        }

        // Pessimistic locking for balance check
        await using var lockHandle = await _lock.AcquireLock(
            $"wallet:{command.WalletId.Value}",
            TimeSpan.FromSeconds(5));

        if (!lockHandle.Acquired)
        {
            _logger.LogWarning("Could not acquire lock for wallet {WalletId}", command.WalletId);
            return new DebitResult(false, "Wallet is currently locked");
        }

        var wallet = await _repository.GetById(command.WalletId);

        if (wallet == null)
        {
            _logger.LogWarning("Wallet {WalletId} not found", command.WalletId);
            return new DebitResult(false, "Wallet not found");
        }

        // Check balance
        if (wallet.Balance < command.Amount.Amount)
        {
            _logger.LogWarning("Insufficient balance in wallet {WalletId}: {Balance} < {Amount}",
                command.WalletId, wallet.Balance, command.Amount.Amount);
            return new DebitResult(false, "Insufficient balance");
        }

        try
        {
            wallet.Debit(command.Amount.Amount, command.Amount.Currency);
            await _repository.Update(wallet);
            await _repository.RecordOperation(command.IdempotencyKey, new { success = true });

            _logger.LogInformation("Debited {Amount} from wallet {WalletId}, new balance {Balance}",
                command.Amount.Amount, command.WalletId, wallet.Balance);

            return new DebitResult(true, transactionId: Guid.NewGuid().ToString());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error debiting wallet {WalletId}", command.WalletId);
            return new DebitResult(false, ex.Message);
        }
    }

    public async Task<CreditResult> Credit(CreditCommand command)
    {
        // Idempotency check
        if (await _repository.IsOperationProcessed(command.IdempotencyKey))
        {
            _logger.LogInformation("Credit operation already processed for key {Key}", command.IdempotencyKey);
            return new CreditResult(true);
        }

        await using var lockHandle = await _lock.AcquireLock(
            $"wallet:{command.WalletId.Value}",
            TimeSpan.FromSeconds(5));

        if (!lockHandle.Acquired)
        {
            return new CreditResult(false, "Wallet is currently locked");
        }

        var wallet = await _repository.GetById(command.WalletId);

        if (wallet == null)
        {
            return new CreditResult(false, "Wallet not found");
        }

        try
        {
            wallet.Credit(command.Amount.Amount, command.Amount.Currency);
            await _repository.Update(wallet);
            await _repository.RecordOperation(command.IdempotencyKey, new { success = true });

            _logger.LogInformation("Credited {Amount} to wallet {WalletId}, new balance {Balance}",
                command.Amount.Amount, command.WalletId, wallet.Balance);

            return new CreditResult(true, transactionId: Guid.NewGuid().ToString());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error crediting wallet {WalletId}", command.WalletId);
            return new CreditResult(false, ex.Message);
        }
    }

    public async Task<DebitResult> ReverseDebit(ReverseDebitCommand command)
    {
        // Idempotency check
        if (await _repository.IsOperationProcessed(command.IdempotencyKey))
        {
            return new DebitResult(true);
        }

        await using var lockHandle = await _lock.AcquireLock(
            $"wallet:{command.WalletId.Value}",
            TimeSpan.FromSeconds(5));

        if (!lockHandle.Acquired)
        {
            return new DebitResult(false, "Wallet is currently locked");
        }

        var wallet = await _repository.GetById(command.WalletId);

        if (wallet == null)
        {
            return new DebitResult(false, "Wallet not found");
        }

        try
        {
            // Reverse debit = credit back the amount
            wallet.Credit(command.Amount.Amount, command.Amount.Currency);
            await _repository.Update(wallet);
            await _repository.RecordOperation(command.IdempotencyKey, new { success = true });

            _logger.LogWarning("Reversed debit of {Amount} to wallet {WalletId} due to: {Reason}",
                command.Amount.Amount, command.WalletId, command.Reason);

            return new DebitResult(true, transactionId: Guid.NewGuid().ToString());
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error reversing debit for wallet {WalletId}", command.WalletId);
            return new DebitResult(false, ex.Message);
        }
    }

    public async Task<bool> IsOperationProcessed(string idempotencyKey)
    {
        return await _repository.IsOperationProcessed(idempotencyKey);
    }
}