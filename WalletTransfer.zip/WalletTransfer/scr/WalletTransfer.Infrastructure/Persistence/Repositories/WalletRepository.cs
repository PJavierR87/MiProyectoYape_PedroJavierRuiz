﻿using Microsoft.EntityFrameworkCore;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Infrastructure.Persistence;

namespace WalletTransfer.Infrastructure.Persistence.Repositories;

public class WalletRepository : IWalletRepository
{
    private readonly WriteDbContext _context;

    public WalletRepository(WriteDbContext context)
    {
        _context = context;
    }

    public async Task<Wallet?> GetById(object id)
    {
        var walletId = id as WalletId ?? WalletId.FromString(id.ToString()!);
        return await _context.Wallets.FirstOrDefaultAsync(w => w.Id == walletId);
    }

    public async Task Add(Wallet entity)
    {
        await _context.Wallets.AddAsync(entity);
    }

    public async Task Update(Wallet entity)
    {
        _context.Entry(entity).State = EntityState.Modified;
        await Task.CompletedTask;
    }

    public async Task Delete(Wallet entity)
    {
        _context.Wallets.Remove(entity);
        await Task.CompletedTask;
    }

    public async Task<bool> IsOperationProcessed(string idempotencyKey)
    {
        return await _context.IdempotencyRecords.AnyAsync(r => r.Key == idempotencyKey);
    }

    public async Task RecordOperation(string idempotencyKey, object response)
    {
        var record = new IdempotencyRecord(idempotencyKey, response);
        await _context.IdempotencyRecords.AddAsync(record);
    }
}