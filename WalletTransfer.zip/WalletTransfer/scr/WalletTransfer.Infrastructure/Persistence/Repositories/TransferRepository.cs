﻿using Microsoft.EntityFrameworkCore;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Infrastructure.Persistence;

namespace WalletTransfer.Infrastructure.Persistence.Repositories;

public class TransferRepository : ITransferRepository
{
    private readonly WriteDbContext _context;
    private readonly Dictionary<TransferId, TransferSagaState> _identityMap = new();

    public TransferRepository(WriteDbContext context)
    {
        _context = context;
    }

    public async Task<TransferSagaState?> GetById(object id)
    {
        var transferId = id as TransferId ?? TransferId.FromString(id.ToString()!);

        if (_identityMap.ContainsKey(transferId))
            return _identityMap[transferId];

        var transfer = await _context.Transfers
            .FirstOrDefaultAsync(t => t.Id == transferId);

        if (transfer != null)
            _identityMap[transferId] = transfer;

        return transfer;
    }

    public async Task<TransferSagaState?> GetByIdempotencyKey(string idempotencyKey)
    {
        return await _context.Transfers
            .FirstOrDefaultAsync(t => t.IdempotencyKey == idempotencyKey);
    }

    public async Task Add(TransferSagaState entity)
    {
        await _context.Transfers.AddAsync(entity);
        _identityMap[entity.Id] = entity;
    }

    public async Task Update(TransferSagaState entity)
    {
        _context.Entry(entity).State = EntityState.Modified;
        _identityMap[entity.Id] = entity;
        await Task.CompletedTask;
    }

    public async Task Delete(TransferSagaState entity)
    {
        _context.Transfers.Remove(entity);
        _identityMap.Remove(entity.Id);
        await Task.CompletedTask;
    }

    public async Task MarkCompleted(TransferId transferId)
    {
        var transfer = await GetById(transferId);
        if (transfer != null)
        {
            transfer.MarkCompleted();
            await Update(transfer);
        }
    }

    public async Task MarkFailedCompensation(TransferId transferId, string error)
    {
        var transfer = await GetById(transferId);
        if (transfer != null)
        {
            transfer.MarkCompensationFailed(error);
            await Update(transfer);
        }
    }

    public async Task MarkAmbiguous(TransferId transferId, string reason)
    {
        var transfer = await GetById(transferId);
        if (transfer != null)
        {
            transfer.MarkAmbiguous(reason);
            await Update(transfer);
        }
    }
}