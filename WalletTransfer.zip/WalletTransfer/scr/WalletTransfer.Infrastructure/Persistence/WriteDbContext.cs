﻿using Microsoft.EntityFrameworkCore;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Infrastructure.Persistence.EntityConfigurations;

namespace WalletTransfer.Infrastructure.Persistence;

public class WriteDbContext : DbContext
{
    public DbSet<Wallet> Wallets { get; set; }
    public DbSet<TransferSagaState> Transfers { get; set; }
    public DbSet<IdempotencyRecord> IdempotencyRecords { get; set; }

    public WriteDbContext(DbContextOptions<WriteDbContext> options) : base(options)
    {
    }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.ApplyConfiguration(new WalletConfiguration());
        modelBuilder.ApplyConfiguration(new TransferConfiguration());
        modelBuilder.ApplyConfiguration(new IdempotencyRecordConfiguration());

        base.OnModelCreating(modelBuilder);
    }
}