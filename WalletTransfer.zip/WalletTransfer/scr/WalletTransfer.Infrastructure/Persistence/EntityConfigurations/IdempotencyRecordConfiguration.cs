﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WalletTransfer.Domain.Entities;

namespace WalletTransfer.Infrastructure.Persistence.EntityConfigurations;

public class IdempotencyRecordConfiguration : IEntityTypeConfiguration<IdempotencyRecord>
{
    public void Configure(EntityTypeBuilder<IdempotencyRecord> builder)
    {
        builder.ToTable("idempotency_records");

        builder.HasKey(i => i.Key);

        builder.Property(i => i.Key)
            .HasColumnName("key")
            .HasMaxLength(255);

        builder.Property(i => i.Response)
            .HasColumnName("response")
            .HasColumnType("jsonb");

        builder.Property(i => i.CreatedAt)
            .HasColumnName("created_at");

        builder.HasIndex(i => i.CreatedAt);
    }
}