﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Infrastructure.Persistence.EntityConfigurations;

public class TransferConfiguration : IEntityTypeConfiguration<TransferSagaState>
{
    public void Configure(EntityTypeBuilder<TransferSagaState> builder)
    {
        builder.ToTable("transfers");

        builder.HasKey(t => t.Id);

        builder.Property(t => t.Id)
            .HasColumnName("id")
            .HasConversion(
                id => id.Value,
                value => new TransferId(value));

        builder.Property(t => t.IdempotencyKey)
            .HasColumnName("idempotency_key")
            .HasMaxLength(255);

        builder.HasIndex(t => t.IdempotencyKey)
            .IsUnique();

        builder.Property(t => t.Status)
            .HasColumnName("status")
            .HasConversion<string>();

        builder.Property(t => t.FromWalletId)
            .HasColumnName("from_wallet_id")
            .HasConversion(
                id => id.Value,
                value => new WalletId(value));

        builder.Property(t => t.ToWalletId)
            .HasColumnName("to_wallet_id")
            .HasConversion(
                id => id.Value,
                value => new WalletId(value));

        builder.OwnsOne(t => t.Amount, money =>
        {
            money.Property(m => m.Amount)
                .HasColumnName("amount")
                .HasPrecision(19, 4);
            money.Property(m => m.Currency)
                .HasColumnName("currency")
                .HasMaxLength(3);
        });

        builder.OwnsOne(t => t.ExchangeRate, money =>
        {
            money.Property(m => m.Amount)
                .HasColumnName("exchange_rate")
                .HasPrecision(19, 6);
            money.Property(m => m.Currency)
                .HasColumnName("target_currency")
                .HasMaxLength(3);
        });

        builder.Property(t => t.CurrentStep)
            .HasColumnName("current_step");

        builder.Property(t => t.RetryCount)
            .HasColumnName("retry_count");

        builder.Property(t => t.FailureReason)
            .HasColumnName("failure_reason")
            .HasMaxLength(1000);

        builder.Property(t => t.CreatedAt)
            .HasColumnName("created_at");

        builder.Property(t => t.UpdatedAt)
            .HasColumnName("updated_at");
    }
}