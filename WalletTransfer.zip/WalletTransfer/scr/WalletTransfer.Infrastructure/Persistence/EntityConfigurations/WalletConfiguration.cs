﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Infrastructure.Persistence.EntityConfigurations;

public class WalletConfiguration : IEntityTypeConfiguration<Wallet>
{
    public void Configure(EntityTypeBuilder<Wallet> builder)
    {
        builder.ToTable("wallets");

        builder.HasKey(w => w.Id);

        builder.Property(w => w.Id)
            .HasColumnName("id")
            .HasConversion(
                id => id.Value,
                value => new WalletId(value));

        builder.Property(w => w.Balance)
            .HasColumnName("balance")
            .HasPrecision(19, 4);

        builder.Property(w => w.Currency)
            .HasColumnName("currency")
            .HasMaxLength(3);

        builder.Property(w => w.Version)
            .HasColumnName("version")
            .IsConcurrencyToken();

        builder.Property(w => w.UpdatedAt)
            .HasColumnName("updated_at");

        builder.HasIndex(w => w.Id);
    }
}