using Microsoft.Extensions.DependencyInjection;
using Serilog;
using WalletTransfer.API.DependencyInjection;
using WalletTransfer.API.Middleware;
using WalletTransfer.Infrastructure.Persistence;
using WalletTransfer.ReadModel.DbContext;

var builder = WebApplication.CreateBuilder(args);

// Configure Serilog
Log.Logger = new LoggerConfiguration()
    .ReadFrom.Configuration(builder.Configuration)
    .Enrich.FromLogContext()
    .Enrich.WithCorrelationId()
    .WriteTo.Console()
    .WriteTo.File("logs/wallettransfer-.txt", rollingInterval: RollingInterval.Day)
    .CreateLogger();

builder.Host.UseSerilog();

// Add services
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// Register all layers
builder.Services.AddApplicationServices();
builder.Services.AddInfrastructureServices(builder.Configuration);
builder.Services.AddOrchestratorServices();
builder.Services.AddReadModelServices(builder.Configuration);

// Add health checks
builder.Services.AddHealthChecks()
    .AddNpgSql(builder.Configuration.GetConnectionString("WriteDatabase")!)
    .AddRedis(builder.Configuration.GetConnectionString("Redis")!)
    .AddKafka(new Confluent.Kafka.ProducerConfig
    {
        BootstrapServers = builder.Configuration["Kafka:BootstrapServers"]!
    });

// Add CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

var app = builder.Build();

// Configure pipeline
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<CorrelationIdMiddleware>();
app.UseMiddleware<ExceptionHandlingMiddleware>();
app.UseMiddleware<RequestLoggingMiddleware>();

app.UseHttpsRedirection();
app.UseCors("AllowAll");
app.UseAuthorization();

app.MapControllers();
app.MapHealthChecks("/health");

// Ensure databases are created
//using (var scope = app.Services.CreateScope())
//{
//    var writeContext = scope.ServiceProvider.GetRequiredService<WriteDbContext>();
//    var readContext = scope.ServiceProvider.GetRequiredService<ReadDbContext>();

//    await writeContext.Database.EnsureCreatedAsync();
//    await readContext.Database.EnsureCreatedAsync();
//}

app.Run();