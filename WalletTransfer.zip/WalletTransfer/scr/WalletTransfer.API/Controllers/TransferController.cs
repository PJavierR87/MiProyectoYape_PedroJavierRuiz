﻿using Microsoft.AspNetCore.Mvc;
using WalletTransfer.Application.Commands;
using WalletTransfer.Application.Validators;
using WalletTransfer.Domain.ValueObjects;
using WalletTransfer.Orchestrator.Saga;
using WalletTransfer.ReadModel.Queries;

namespace WalletTransfer.API.Controllers;

[ApiController]
[Route("api/[controller]")]
public class TransferController : ControllerBase
{
    private readonly TransferOrchestrator _orchestrator;
    private readonly TransferQueries _queries;
    private readonly ILogger<TransferController> _logger;

    public TransferController(
        TransferOrchestrator orchestrator,
        TransferQueries queries,
        ILogger<TransferController> logger)
    {
        _orchestrator = orchestrator;
        _queries = queries;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> StartTransfer([FromBody] StartTransferRequest request)
    {
        try
        {
            var validator = new StartTransferCommandValidator();
            var command = new StartTransferCommand(
                TransferId.Create(),
                new WalletId(request.FromWalletId),
                new WalletId(request.ToWalletId),
                new Money(request.Amount, request.Currency),
                new Money(request.ExchangeRate, request.TargetCurrency),
                request.IdempotencyKey);

            var validationResult = await validator.ValidateAsync(command);
            if (!validationResult.IsValid)
            {
                return BadRequest(validationResult.Errors);
            }

            var result = await _orchestrator.StartTransfer(command);

            if (result.Success)
            {
                return Accepted(new { transferId = result.TransferId?.Value, status = result.Status.ToString() });
            }

            return BadRequest(new { error = result.Error });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error starting transfer");
            return StatusCode(500, new { error = "Internal server error" });
        }
    }

    [HttpGet("{id}")]
    public async Task<IActionResult> GetTransfer(string id)
    {
        var transfer = await _queries.GetTransfer(id);

        if (transfer == null)
            return NotFound();

        return Ok(transfer);
    }

    [HttpGet("wallet/{walletId}")]
    public async Task<IActionResult> GetTransfersByWallet(string walletId, [FromQuery] int page = 1, [FromQuery] int pageSize = 20)
    {
        var transfers = await _queries.GetTransfersByWallet(walletId, page, pageSize);
        return Ok(transfers);
    }
}

public class StartTransferRequest
{
    public string FromWalletId { get; set; } = string.Empty;
    public string ToWalletId { get; set; } = string.Empty;
    public decimal Amount { get; set; }
    public string Currency { get; set; } = string.Empty;
    public decimal ExchangeRate { get; set; }
    public string TargetCurrency { get; set; } = string.Empty;
    public string IdempotencyKey { get; set; } = string.Empty;
}