﻿using System.Net;
using System.Text.Json;
using WalletTransfer.Domain.Exceptions;

namespace WalletTransfer.API.Middleware;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "An unhandled exception occurred");
            await HandleExceptionAsync(context, ex);
        }
    }

    private static async Task HandleExceptionAsync(HttpContext context, Exception exception)
    {
        var response = context.Response;
        response.ContentType = "application/json";

        var errorResponse = new
        {
            error = exception.Message,
            type = exception.GetType().Name,
            timestamp = DateTime.UtcNow
        };

        switch (exception)
        {
            case BusinessException:
                response.StatusCode = (int)HttpStatusCode.BadRequest;
                break;
            case ConcurrencyException:
                response.StatusCode = (int)HttpStatusCode.Conflict;
                break;
            case CompensationException:
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                break;
            default:
                response.StatusCode = (int)HttpStatusCode.InternalServerError;
                errorResponse = new { error = "An internal error occurred", type = "InternalError", timestamp = DateTime.UtcNow };
                break;
        }

        var json = JsonSerializer.Serialize(errorResponse);
        await response.WriteAsync(json);
    }
}