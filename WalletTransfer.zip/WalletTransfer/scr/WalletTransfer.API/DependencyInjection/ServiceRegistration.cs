﻿using Microsoft.EntityFrameworkCore;
using StackExchange.Redis;
using WalletTransfer.Application.Services;
using WalletTransfer.Domain.Interfaces;
using WalletTransfer.Infrastructure.Cache.Redis;
using WalletTransfer.Infrastructure.Configuration;
using WalletTransfer.Infrastructure.ExternalServices.FX;
using WalletTransfer.Infrastructure.Messaging.Kafka;
using WalletTransfer.Infrastructure.Persistence;
using WalletTransfer.Infrastructure.Persistence.Repositories;
using WalletTransfer.Infrastructure.Services; // Agregar esta línea
using WalletTransfer.Orchestrator.Saga;
using WalletTransfer.ReadModel.DbContext;
using WalletTransfer.ReadModel.Projections;
using WalletTransfer.ReadModel.Queries;
namespace WalletTransfer.API.DependencyInjection;

public static class ServiceRegistration
{
    public static IServiceCollection AddApplicationServices(this IServiceCollection services)
    {
        services.AddScoped<IWalletService, WalletService>();
        return services;
    }

    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Database
        services.AddDbContext<WriteDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("WriteDatabase")));

        // Repositories
        services.AddScoped<ITransferRepository, TransferRepository>();
        services.AddScoped<IWalletRepository, WalletRepository>();
        services.AddScoped<IEventPublisher, KafkaEventPublisher>();

        // Cache and Lock
        var redisConnectionString = configuration.GetConnectionString("Redis");
        services.AddSingleton<IConnectionMultiplexer>(sp =>
            ConnectionMultiplexer.Connect(redisConnectionString!));
        services.AddScoped<IDistributedLock, RedisDistributedLock>();

        // Configuration
        services.Configure<KafkaConfig>(configuration.GetSection("Kafka"));
        services.Configure<FXConfig>(configuration.GetSection("FXService"));

        // External Services
        services.AddHttpClient<IFXService, FXService>(client =>
        {
            client.BaseAddress = new Uri(configuration["FXService:BaseUrl"]!);
            client.Timeout = TimeSpan.FromSeconds(configuration.GetValue<int>("FXService:TimeoutSeconds", 5));
        });

        return services;
    }

    public static IServiceCollection AddOrchestratorServices(this IServiceCollection services)
    {
        services.AddScoped<TransferOrchestrator>();
        return services;
    }

    public static IServiceCollection AddReadModelServices(this IServiceCollection services, IConfiguration configuration)
    {
        // Read Database
        services.AddDbContext<ReadDbContext>(options =>
            options.UseNpgsql(configuration.GetConnectionString("ReadDatabase")));

        // Cache
        services.AddStackExchangeRedisCache(options =>
        {
            options.Configuration = configuration.GetConnectionString("Redis");
        });

        // Queries and Projections
        services.AddScoped<TransferQueries>();
        services.AddScoped<TransferProjector>();

        return services;
    }
}