﻿namespace WalletTransfer.Domain.ValueObjects;

public record TransferId
{
    public string Value { get; }

    public TransferId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Transfer ID cannot be empty");
        Value = value;
    }

    public static TransferId Create() => new(Guid.NewGuid().ToString());
    public static TransferId FromString(string value) => new(value);

    public override string ToString() => Value;
}