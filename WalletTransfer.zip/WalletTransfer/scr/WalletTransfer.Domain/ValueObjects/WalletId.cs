﻿namespace WalletTransfer.Domain.ValueObjects;

public record WalletId
{
    public string Value { get; }

    public WalletId(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Wallet ID cannot be empty");
        Value = value;
    }

    public static WalletId Create() => new(Guid.NewGuid().ToString());
    public static WalletId FromString(string value) => new(value);

    public override string ToString() => Value;
}