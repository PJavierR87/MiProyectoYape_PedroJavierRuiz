﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class TransferFailedEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public string Reason { get; }
    public string Step { get; }

    public TransferFailedEvent(TransferId transferId, string reason, string step)
    {
        TransferId = transferId;
        Reason = reason;
        Step = step;
    }

    public override string EventType => nameof(TransferFailedEvent);
}