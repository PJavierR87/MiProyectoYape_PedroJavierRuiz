﻿namespace WalletTransfer.Domain.Events;

public interface IEvent
{
    DateTime Timestamp { get; }
    string EventType { get; }
}

public abstract class BaseEvent : IEvent
{
    public DateTime Timestamp { get; protected set; } = DateTime.UtcNow;
    public abstract string EventType { get; }
}