﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class TransferStartedEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public WalletId FromWallet { get; }
    public WalletId ToWallet { get; }
    public Money Amount { get; }

    public TransferStartedEvent(TransferId transferId, WalletId fromWallet, WalletId toWallet, Money amount)
    {
        TransferId = transferId;
        FromWallet = fromWallet;
        ToWallet = toWallet;
        Amount = amount;
    }

    public override string EventType => nameof(TransferStartedEvent);
}