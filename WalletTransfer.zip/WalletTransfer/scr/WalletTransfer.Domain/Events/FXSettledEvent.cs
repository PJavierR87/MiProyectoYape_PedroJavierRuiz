﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class FXSettledEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public Money ExchangeRate { get; }

    public FXSettledEvent(TransferId transferId, Money exchangeRate)
    {
        TransferId = transferId;
        ExchangeRate = exchangeRate;
    }

    public override string EventType => nameof(FXSettledEvent);
}