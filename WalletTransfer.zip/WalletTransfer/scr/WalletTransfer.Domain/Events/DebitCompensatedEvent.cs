﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class DebitCompensatedEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public WalletId WalletId { get; }
    public Money Amount { get; }
    public string Reason { get; }

    public DebitCompensatedEvent(TransferId transferId, WalletId walletId, Money amount, string reason)
    {
        TransferId = transferId;
        WalletId = walletId;
        Amount = amount;
        Reason = reason;
    }

    public override string EventType => nameof(DebitCompensatedEvent);
}