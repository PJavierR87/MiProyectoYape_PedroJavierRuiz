﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class WalletDebitedEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public WalletId WalletId { get; }
    public Money Amount { get; }

    public WalletDebitedEvent(TransferId transferId, WalletId walletId, Money amount)
    {
        TransferId = transferId;
        WalletId = walletId;
        Amount = amount;
    }

    public override string EventType => nameof(WalletDebitedEvent);
}