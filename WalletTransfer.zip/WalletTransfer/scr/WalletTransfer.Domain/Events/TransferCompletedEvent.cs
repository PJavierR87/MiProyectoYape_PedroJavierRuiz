﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Events;

public class TransferCompletedEvent : BaseEvent
{
    public TransferId TransferId { get; }
    public string ReceiptUrl { get; }

    public TransferCompletedEvent(TransferId transferId, string receiptUrl)
    {
        TransferId = transferId;
        ReceiptUrl = receiptUrl;
    }

    public override string EventType => nameof(TransferCompletedEvent);
}