﻿namespace WalletTransfer.Domain.Interfaces;

public interface IDistributedLock
{
    Task<ILockHandle> AcquireLock(string resource, TimeSpan timeout);
}

public interface ILockHandle : IAsyncDisposable
{
    bool Acquired { get; }
}