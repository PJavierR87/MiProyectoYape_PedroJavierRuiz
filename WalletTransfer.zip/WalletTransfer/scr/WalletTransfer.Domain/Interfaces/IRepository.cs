﻿namespace WalletTransfer.Domain.Interfaces;

public interface IRepository<T>
{
    Task<T?> GetById(object id);
    Task Add(T entity);
    Task Update(T entity);
    Task Delete(T entity);
}