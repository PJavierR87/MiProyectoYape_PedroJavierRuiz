﻿using WalletTransfer.Domain.Entities;

namespace WalletTransfer.Domain.Interfaces;

public interface IWalletRepository : IRepository<Wallet>
{
    Task<bool> IsOperationProcessed(string idempotencyKey);
    Task RecordOperation(string idempotencyKey, object response);
}