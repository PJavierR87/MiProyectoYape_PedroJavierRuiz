﻿using WalletTransfer.Domain.Events;

namespace WalletTransfer.Domain.Interfaces;

public interface IEventPublisher
{
    Task Publish<T>(T @event) where T : IEvent;
}