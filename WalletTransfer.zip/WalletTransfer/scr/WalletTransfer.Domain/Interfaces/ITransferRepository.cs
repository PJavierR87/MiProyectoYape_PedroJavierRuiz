﻿using WalletTransfer.Domain.Entities;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Interfaces;

public interface ITransferRepository : IRepository<TransferSagaState>
{
    Task<TransferSagaState?> GetByIdempotencyKey(string idempotencyKey);
    Task MarkCompleted(TransferId transferId);
    Task MarkFailedCompensation(TransferId transferId, string error);
    Task MarkAmbiguous(TransferId transferId, string reason);
}