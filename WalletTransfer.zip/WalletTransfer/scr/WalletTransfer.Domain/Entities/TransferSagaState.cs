﻿using WalletTransfer.Domain.Enums;
using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Entities;

public class TransferSagaState
{
    public TransferId Id { get; private set; }
    public string IdempotencyKey { get; private set; }
    public TransferStatus Status { get; private set; }
    public WalletId FromWalletId { get; private set; }
    public WalletId ToWalletId { get; private set; }
    public Money Amount { get; private set; }
    public Money ExchangeRate { get; private set; }
    public int CurrentStep { get; private set; }
    public int RetryCount { get; private set; }
    public string? FailureReason { get; private set; }
    public DateTime CreatedAt { get; private set; }
    public DateTime? UpdatedAt { get; private set; }

    private TransferSagaState() { }

    public TransferSagaState(
        TransferId id,
        string idempotencyKey,
        WalletId fromWalletId,
        WalletId toWalletId,
        Money amount,
        Money exchangeRate)
    {
        Id = id;
        IdempotencyKey = idempotencyKey;
        FromWalletId = fromWalletId;
        ToWalletId = toWalletId;
        Amount = amount;
        ExchangeRate = exchangeRate;
        Status = TransferStatus.Pending;
        CurrentStep = 0;
        RetryCount = 0;
        CreatedAt = DateTime.UtcNow;
    }

    public void UpdateStep(int step, TransferStatus status)
    {
        CurrentStep = step;
        Status = status;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkFailed(string reason)
    {
        Status = TransferStatus.Failed;
        FailureReason = reason;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkCompensating()
    {
        Status = TransferStatus.Compensating;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkCompensated()
    {
        Status = TransferStatus.Compensated;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkCompleted()
    {
        Status = TransferStatus.Completed;
        CurrentStep = 4;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkAmbiguous(string reason)
    {
        Status = TransferStatus.Ambiguous;
        FailureReason = reason;
        UpdatedAt = DateTime.UtcNow;
    }

    public void MarkCompensationFailed(string error)
    {
        Status = TransferStatus.Failed;
        FailureReason = $"Compensation failed: {error}";
        UpdatedAt = DateTime.UtcNow;
    }

    public void IncrementRetry()
    {
        RetryCount++;
        UpdatedAt = DateTime.UtcNow;
    }
}