﻿namespace WalletTransfer.Domain.Entities;

public class IdempotencyRecord
{
    public string Key { get; private set; }
    public object Response { get; private set; }
    public DateTime CreatedAt { get; private set; }

    private IdempotencyRecord() { }

    public IdempotencyRecord(string key, object response)
    {
        Key = key;
        Response = response;
        CreatedAt = DateTime.UtcNow;
    }
}