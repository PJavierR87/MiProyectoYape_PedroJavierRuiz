﻿using WalletTransfer.Domain.ValueObjects;

namespace WalletTransfer.Domain.Entities;

public class Wallet
{
    public WalletId Id { get; private set; }
    public decimal Balance { get; private set; }
    public string Currency { get; private set; }
    public int Version { get; private set; }
    public DateTime UpdatedAt { get; private set; }

    private Wallet() { }

    public Wallet(WalletId id, string currency)
    {
        Id = id;
        Currency = currency;
        Balance = 0;
        Version = 0;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Debit(decimal amount, string currency)
    {
        if (currency != Currency)
            throw new InvalidOperationException($"Currency mismatch: expected {Currency}, got {currency}");

        if (Balance < amount)
            throw new InvalidOperationException($"Insufficient balance: {Balance} < {amount}");

        Balance -= amount;
        Version++;
        UpdatedAt = DateTime.UtcNow;
    }

    public void Credit(decimal amount, string currency)
    {
        if (currency != Currency)
            throw new InvalidOperationException($"Currency mismatch: expected {Currency}, got {currency}");

        Balance += amount;
        Version++;
        UpdatedAt = DateTime.UtcNow;
    }
}