﻿namespace WalletTransfer.Domain.Exceptions;

public abstract class DomainException : Exception
{
    protected DomainException(string message) : base(message) { }
    protected DomainException(string message, Exception innerException) : base(message, innerException) { }
}

public class ConcurrencyException : DomainException
{
    public ConcurrencyException(string message) : base(message) { }
}

public class BusinessException : DomainException
{
    public BusinessException(string message) : base(message) { }
}

public class CompensationException : DomainException
{
    public CompensationException(string message) : base(message) { }
    public CompensationException(string message, Exception innerException) : base(message, innerException) { }
}