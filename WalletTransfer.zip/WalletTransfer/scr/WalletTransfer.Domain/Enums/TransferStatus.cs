﻿namespace WalletTransfer.Domain.Enums;

public enum TransferStatus
{
    Pending = 0,
    DebitCompleted = 1,
    CreditCompleted = 2,
    Settled = 3,
    Completed = 4,
    Failed = 5,
    Compensating = 6,
    Compensated = 7,
    Ambiguous = 8
}