﻿namespace WalletTransfer.Domain.Enums;

public enum TransactionType
{
    Debit = 1,
    Credit = 2,
    ReverseDebit = 3,
    ReverseCredit = 4
}