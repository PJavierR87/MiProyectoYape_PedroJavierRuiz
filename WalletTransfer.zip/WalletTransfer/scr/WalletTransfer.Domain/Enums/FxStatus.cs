﻿namespace WalletTransfer.Domain.Enums;

public enum FxStatus
{
    Pending = 0,
    Confirmed = 1,
    Failed = 2,
    Unknown = 3
}